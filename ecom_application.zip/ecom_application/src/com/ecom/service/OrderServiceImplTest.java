package com.ecom.service;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;

public class OrderServiceImplTest {
	private IOrderService orderService;

	@Before
	public void setUp() throws Exception {
		orderService = new OrderServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		orderService = null;
	}

	@Test
	public final void testPlaceOrder() {
		Customer customer = new Customer("John", "john@example.com", "password");
		Product product = new Product("Smartphone", 800.00, "Latest smartphone model", 10);

		List<Map<Product, Integer>> productsInOrder = new ArrayList<>();
		productsInOrder.add(Map.of(product, 2));

		orderService.placeOrder(customer, productsInOrder, "address");
		assertTrue(true);
	}

	@Test
	public final void testGetOrdersByCustomer() {
		Customer customer = new Customer("John", "john@example.com", "password");
		customer.setCustomerId(1);
		List<Map<Product, Integer>> orders = orderService.getOrdersByCustomer(customer.getCustomerId());
		assertTrue(orders != null);

	}
}
