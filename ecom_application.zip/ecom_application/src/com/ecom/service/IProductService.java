package com.ecom.service;

import java.util.List;

import com.ecom.entity.Product;

public interface IProductService {
	public boolean createProduct(Product product);

	public boolean deleteProduct(int productId) ;

	public Product viewProduct(int productId) ;

	public List<Product> viewProducts() ;
}
