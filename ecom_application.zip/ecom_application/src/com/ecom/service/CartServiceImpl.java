package com.ecom.service;

import java.sql.SQLException;
import java.util.List;

import com.ecom.dao.CartDAOImpl;
import com.ecom.dao.ICartDAO;
import com.ecom.entity.Customer;
import com.ecom.entity.Product;

public class CartServiceImpl implements ICartService {

	private ICartDAO iCartDAO;

    public CartServiceImpl() {
    	super();
        this.iCartDAO = new CartDAOImpl();
    }

    @Override
    public boolean addToCart(Customer customer, Product product, int quantity) {
    	boolean result = false;
		try {
			result = iCartDAO.addToCart(customer,product,quantity);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
        
    }

    @Override
    public boolean removeFromCart(Customer customer, Product product) {
    	boolean result=false;
        try {
            result= iCartDAO.removeFromCart(customer, product);
        } catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
    }

    @Override
    public List<Product> getAllFromCart(Customer customer) {
    	List<Product> cartList = null;
        try {
            cartList= iCartDAO.getAllFromCart(customer);
        }catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return cartList;
    }
}
