package com.ecom.dao;

import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;
import com.ecom.exception.OrderNotFoundException;
import com.ecom.exception.ProductNotFoundException;

public class OrderDAOImplTest {

	private IOrderDAO orderDAO;

	@Before
	public void setUp() throws Exception {
		orderDAO = new OrderDAOImpl();

	}

	@After
	public void tearDown() throws Exception {
		orderDAO = null;

	}

	@Test
	public final void testGetOrdersByCustomer() {
		Customer customer = new Customer("John", "john@example.com", "password");
		customer.setCustomerId(2);
		List<Map<Product, Integer>> orders = null;
		try {
			orders = orderDAO.getOrdersByCustomer(customer.getCustomerId());
		} catch (ClassNotFoundException | SQLException | OrderNotFoundException | ProductNotFoundException e) {
			e.printStackTrace();
		}
		assertTrue(orders != null);

	}

	@Test
	public final void testPlaceOrder() {
		Customer customer = new Customer("Johnwick", "john@gmail.com", "john1234");

		Product product = new Product("Laptop", 1200.00, "High-performance laptop", 5);

		try {

			ICartDAO cartDAO = new CartDAOImpl();
			cartDAO.addToCart(customer, product, 1);

			List<Map<Product, Integer>> productsInOrder = new ArrayList<>();
			Map<Product, Integer> productQuantityMap = new HashMap<>();
			productQuantityMap.put(product, 1);
			productsInOrder.add(productQuantityMap);

			orderDAO.placeOrder(customer, productsInOrder, "Urgent delivery");

		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username, or password is wrong or duplicate record");
		}

		assertTrue(true);
	}

}
