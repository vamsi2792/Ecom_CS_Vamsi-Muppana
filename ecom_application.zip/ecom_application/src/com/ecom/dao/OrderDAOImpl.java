package com.ecom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;
import com.ecom.exception.OrderNotFoundException;
import com.ecom.exception.ProductNotFoundException;
import com.ecom.util.DBUtil;

public class OrderDAOImpl implements IOrderDAO {

	@Override
	public boolean placeOrder(Customer customer, List<Map<Product, Integer>> productsAndQuantities,
			String shippingAddress) throws ClassNotFoundException, SQLException {
		Connection connection = DBUtil.createConnection();
		connection.setAutoCommit(false);

		int orderId = insertOrder(connection, customer, shippingAddress, productsAndQuantities);

		for (Map<Product, Integer> entry : productsAndQuantities) {
			for (Map.Entry<Product, Integer> productEntry : entry.entrySet()) {
				insertOrderItem(connection, orderId, productEntry.getKey(), productEntry.getValue());
			}
		}

		connection.commit();
		return true;

	}

	@Override
	public List<Map<Product, Integer>> getOrdersByCustomer(int customerId)
			throws ClassNotFoundException, SQLException, OrderNotFoundException, ProductNotFoundException {
		Connection connection = DBUtil.createConnection();
		String sql = "SELECT o.order_id, oi.product_id, oi.quantity FROM orders o "
				+ "JOIN order_items oi ON o.order_id = oi.order_id WHERE o.customer_id = ?";
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, customerId);

		ResultSet resultSet = statement.executeQuery();
		Map<Integer, Map<Product, Integer>> orderMap = new HashMap<>();

		while (resultSet.next()) {
			int orderId = resultSet.getInt("order_id");
			int productId = resultSet.getInt("product_id");
			int quantity = resultSet.getInt("quantity");

			orderMap.computeIfAbsent(orderId, k -> new HashMap<>()).put(getProductById(productId), quantity);
		}

		if (orderMap.isEmpty()) {
			throw new OrderNotFoundException("No orders found for customer with ID: " + customerId);
		}

		return new ArrayList<>(orderMap.values());

	}

	private int insertOrder(Connection connection, Customer customer, String shippingAddress,
			List<Map<Product, Integer>> productsAndQuantities) throws SQLException {
		String sql = "INSERT INTO orders (customer_id, order_date, total_price, shipping_address) VALUES (?, NOW(), ?, ?)";

		double totalPrice = calculateTotalPrice(productsAndQuantities);

		PreparedStatement statement = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
		statement.setInt(1, customer.getCustomerId());
		statement.setDouble(2, totalPrice);
		statement.setString(3, shippingAddress);

		int rowsInserted = statement.executeUpdate();
		if (rowsInserted == 0) {
			throw new SQLException("Failed to insert order, no rows affected.");
		}

		ResultSet generatedKeys = statement.getGeneratedKeys();
		if (generatedKeys.next()) {
			return generatedKeys.getInt(1);
		} else {
			throw new SQLException("Failed to get order ID, no keys generated.");
		}

	}

	private void insertOrderItem(Connection connection, int orderId, Product product, int quantity)
			throws SQLException {
		String sql = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)";
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, orderId);
		statement.setInt(2, product.getProductId());
		statement.setInt(3, quantity);

		statement.executeUpdate();

	}

	private Product getProductById(int productId)
			throws ClassNotFoundException, SQLException, ProductNotFoundException {
		String sql = "SELECT * FROM products WHERE product_id = ?";

		Connection connection = DBUtil.createConnection();
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, productId);

		ResultSet resultSet = statement.executeQuery();
		if (resultSet.next()) {
			Product product = new Product();
			product.setProductId(resultSet.getInt("product_id"));
			product.setName(resultSet.getString("name"));
			product.setPrice(resultSet.getDouble("price"));
			product.setDescription(resultSet.getString("description"));
			product.setStockQuantity(resultSet.getInt("stock_quantity"));

			return product;
		} else {
			throw new ProductNotFoundException("Product not found with ID: " + productId);
		}

	}

	private double calculateTotalPrice(List<Map<Product, Integer>> productsAndQuantities) {
		double totalPrice = 0.0;

		for (Map<Product, Integer> entry : productsAndQuantities) {
			for (Map.Entry<Product, Integer> productEntry : entry.entrySet()) {
				Product product = productEntry.getKey();
				int quantity = productEntry.getValue();
				totalPrice += product.getPrice() * quantity;
			}
		}

		return totalPrice;
	}
}
